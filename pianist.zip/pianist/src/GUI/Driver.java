package GUI;

public class Driver {
	private static final double VERSION = 2.1;

	public static void main(String[] args) {
		MainFrame frame = new MainFrame ();
		frame.setVisible(true);		
	}

}
 