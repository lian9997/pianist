package model;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;

import javax.sound.midi.Instrument;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Synthesizer;

public class Player implements Comparator<Player.Node> {

	LinkedList<Node> nodeList;
	PriorityQueue<Node> playQueue;
	int[] insts = { 0, 16, 32, 48, 64, 80 };
	int currNode;
	int currStep;
	int nodecount;
	int currCh;

	Synthesizer synthesizer;
	MidiChannel[] midiChannel;
	Instrument instruments[];

	public Player() {
		nodeList = new LinkedList<Node>();
		playQueue = new PriorityQueue<Node>(this);
		currNode = 80;
		currCh = 8;
		try {
			synthesizer = MidiSystem.getSynthesizer();
			synthesizer.open();
			midiChannel = synthesizer.getChannels();
			instruments = synthesizer.getAvailableInstruments();
		} catch (Exception e) {
			e.printStackTrace();
		}
		for (MidiChannel ch : midiChannel) {
			ch.programChange(0);
		}
	}

	public void play() {
		while (!playQueue.isEmpty() && playQueue.peek().endtime < System.currentTimeMillis()) {
			Node now = playQueue.poll();
			midiChannel[now.ch].allNotesOff();
		}

	}

	public void play(int tone) {
		if (tone == -1) {
			play();
		} else {
			Node newnode = new Node(currNode, System.currentTimeMillis() + 500, (currCh = (currCh + 1) % 9));
			playQueue.add(newnode);
			midiChannel[currCh].noteOn(tone, 100);
		}
	}

	@Override
	public int compare(Node n0, Node n1) {
		return (int) (n0.endtime - n1.endtime);
	}

	public void setinst(int inst) {
		for (int i = 0; i < 9; i++) {
			midiChannel[i].programChange(inst);
		}
	}

	class Node {
		final int tone;
		final long endtime;
		int ch;

		Node(int d, long o, int c) {
			tone = d;
			endtime = o;
			ch = c;
		}
	}

}
