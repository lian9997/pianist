package model;

import javax.sound.midi.*;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class Model {
	private static final double VERSION = 2.1;
	int midiNote;
	Player player;
	int currInst;

	LinkedList<Node> song;

	public Model() {
		player = new Player();
		song = new LinkedList<Node>();
	}

	synchronized public void setOriginNote(int note) {
		midiNote = note;
		song.add(new Node(currInst, 0, 200));
		player.play(midiNote);
		song.add(new Node(currInst, midiNote, 200));
	}

	synchronized public void check() {
		player.play();
	}

	/* start a new thread to play the sound */
	synchronized public void nextStep(double degree) {

		if (inBetween(0, 30, degree) || inBetween(150, 180, degree) || degree == 360) {
			midiNote += 4;
		} else if (inBetween(30, 60, degree) || inBetween(120, 150, degree)) {
			midiNote += 3;
		} else if (inBetween(60, 120, degree)) {
			midiNote += 5;
		} else if (inBetween(180, 210, degree) || inBetween(330, 360, degree)) {
			midiNote -= 4;
		} else if (inBetween(210, 240, degree) || inBetween(300, 330, degree)) {
			midiNote -= 3;
		} else if (inBetween(240, 300, degree)) {
			midiNote -= 5;
		}

		player.play(midiNote);
		song.add(new Node(currInst, midiNote, 200));
	}

	static boolean inBetween(int x, int y, double degree) {
		if (degree >= x && degree < y) {
			return true;
		}
		return false;
	}

	public void setInstrucment(int instnum) {
		// TODO Auto-generated method stub
		currInst = instnum;
		player.setinst(instnum);
	}

	public String getInstrumentName(int instnum) {
		return "name";
	}

	public void saveAudio() {
		// TODO Auto-generated method stub
		System.out.println("not implemented.");

	}

	public void playAll() {
		try {
		for (Node n : song) {
			if (currInst != n.inst) {
				currInst = n.inst;
				player.setinst(n.inst);
			}
			player.play(n.tone);
				Thread.sleep(200);
		}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return;
	}

	class Node {
		final int inst;
		final int tone;
		final int time;

		Node(int i, int d, int t) {
			inst = i;
			tone = d;
			time = t;
		}
	}
}
